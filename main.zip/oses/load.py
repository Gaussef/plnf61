import main
main.main()
#================== SCRIPT BY APFRS ==================#